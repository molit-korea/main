output = open('output080100003', 'a')
import gzip
import re

with gzip.open('D:/DTG/0801/1/part-r-00003.gz', 'rb') as f:
    i = 0
    c = 0

    file_content = f.readline()
    while file_content :
        data = str(file_content)
        data = str(data[2:-3])
#        print(data)
#        print(data.__len__())
        k = 0
        for i in range(0,data.__len__()) :
           if data[i]== '|':
                k = k + 1
                if k == 12 :
                    xs = data[i+1:i+10]
                if k == 13 :
                    ys = data[i+1:i+10]
        x = int(xs)
        y = int(ys)

        if 126975223 <= x and x <= 127000821 and 37570041 <= y and y <= 37571045 :
            output.write(data+'\n')
#            print('jongro')
        file_content=f.readline()
#    reg = re.compile('(([a-z]|[A-Z]|\d|[-]|[+]|[.]|[,]|[ ]|["\"])*[|]){12}')
'''    reg = re.compile('((\w|\-|\.|\\|\,|\(|\)|\'|\"|\;|\:|\{|\}|\=|\+|[,]|\s|[\\\\])*[|]){12}')
    data = str(file_content)
    data = data[2:-3]
    m = re.match(reg,data).end()
    ys = data[m:m+9]
    xs = data[m+10:m+19]
    y = int(ys)
    x = int(xs)

    while file_content :
        data = str(file_content)
        data = data[2:-3]
#        print(data, re.match(reg, data))
        if re.match(reg, data) == None :
            file_content = f.readline()
            continue
        else :
            m = re.match(reg, data).end()
            ys = data[m:m + 9]
            xs = data[m + 10:m + 19]
            y = int(ys)
            x = int(xs)

            if 126975223 <= x and x <= 127000821 and 37570041 <= y and y <= 37571045:
                output.write(data + '\n')
            file_content = f.readline()
'''

#[|] ## 12 13번째 | 뒤가 각각 좌표
#    while file_content :
#        data = str(file_content)
#        print(data)
#
#        print(data[123:132] + " " + data[134:142])
#        xs = data[123:132]
#        ys = data[134:142]
#        x = int(xs)
#        y = int(ys)
#

'''
    s1 = data[2:28]
    while file_content:
        file_content = f.readline()

        data = str(file_content)
        s2 = data[2:28]
        #        print(s1+' : '+s2)
        i = i + 1
        if s1 != s2:
            print(str(c) + ' : ' + str(i))
            c = c + 1
            if c == 1000:
                break
        #        if i == 100 :
        #            output080100001.write(str(file_content[2:-1]))
        #            break
        s1 = s2
print("end")
f.close()
import gzip

with gzip.open('D:/DTG/0801/1/part-r-00002.gz', 'rb') as f:
    print('new')
'''
f.close()


print("finished")
output.close()